//Assignment 05
//Assignment05.zip
//Alex Ilevbare

package com.example.assignment05;


public interface FragmentNavigationListener {
    void onStartClicked();
    void onUserCreated(User user);
    void onUpdateClicked(User user);
    void onUserUpdated(User user);
}
